import { PokemonRoot } from '../Interfaces/pokemon';

export const getPokemon = async (pokemonName: string): Promise<PokemonRoot> => {
    const datosPokemon = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
    const data: PokemonRoot = await datosPokemon.json();
    return data;
};

export const getPokemonId = async (id: number): Promise<PokemonRoot> => {
    const IdPokemon = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
    const data: PokemonRoot = await IdPokemon.json();
    return data;
};

//obtiene la especie d el pokemon
export const getSpecies = async (pokemonName: string): Promise<PokemonRoot> => {
    const datosEspecie = await fetch(`https://pokeapi.co/api/v2/pokemon-species/${pokemonName}`);
    const data: PokemonRoot = await datosEspecie.json();
    return data;
};
