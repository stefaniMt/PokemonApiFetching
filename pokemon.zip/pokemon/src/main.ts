
import { getPokemon, getSpecies, getPokemonId } from './PokemonController.ts/PokControllers';
import { PokemonRoot } from './Interfaces/pokemon';

const main = async () => {
    const pokemonId = 8; //id del pokemon

    //datos del pokemon
    const pokemById: PokemonRoot = await getPokemonId(pokemonId);
    console.log("⭐ Datos del Pokémon:");
    console.log(`☆ Nombre: ${pokemById.name}`);

    const pokemonName = pokemById.name;

    const pokem: PokemonRoot = await getPokemon(pokemonName);
    console.log(`☆ Altura: ${pokem.height}`);
    console.log(`☆ Peso: ${pokem.weight}`);

    //habilidades del pokemon
    const habilidades = pokem.abilities.map(ability => ability.ability.name).join(", ");
    console.log(`Habilidades: ${habilidades}`);

    //especie
    const species: PokemonRoot = await getSpecies(pokemonName);
    console.log(`Especie: ${species.name}`);

    //tipos
    const tipos = pokem.types.map(type => type.type.name).join(", ");
    console.log(`Tipos: ${tipos}`);

    };
    main()//ejecución del programa
