//json -> interface
export interface Root {
    count: number
    next: string
    previous: any
    results: Result[]
  }
  
  export interface Result {
    name: string
    url: string
  }
  
//root
export interface PokemonRoot {
    id: number
    name: string;
    height: number;
    weight: number;
    abilities: { ability: { name: string } }[];
    species: { name: string; url: string };
    types: { type: { name: string } }[];
}